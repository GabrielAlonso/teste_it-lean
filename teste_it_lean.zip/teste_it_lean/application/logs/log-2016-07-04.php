<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-04 20:05:29 --> Severity: Notice --> Undefined index: log_threshold C:\wamp\www\teste_it_lean\system\core\Log.php 129
ERROR - 2016-07-04 20:05:29 --> Severity: Notice --> Undefined index: log_threshold C:\wamp\www\teste_it_lean\system\core\Log.php 133
ERROR - 2016-07-04 20:05:29 --> Severity: Notice --> Undefined index: log_threshold C:\wamp\www\teste_it_lean\system\core\Log.php 129
ERROR - 2016-07-04 20:05:29 --> Severity: Notice --> Undefined index: log_threshold C:\wamp\www\teste_it_lean\system\core\Log.php 133

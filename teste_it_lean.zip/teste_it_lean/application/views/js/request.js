$(document).ready(function() {
	$('#salvar').click(function() {
		var dados = $('#formulario_teste').serialize();
			$.ajax({
				url: '<?php echo base_url(); ?>' + 'index.php/registros_controller/cadatrar',
                type: 'POST',
                dataType: 'json',
                async: true,
                data: dados,
                success: function(response) {
                    location.reload();
                }
            });
            return false;

    });
});
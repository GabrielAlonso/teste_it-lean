<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<html xmlns="http://www.w3.org/1999/xhtml" ng-app="itlean" class="ng-scope">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Teste - Gabriel J. Alonso</title>

    <!-- Bootstrap Core CSS -->
    <link href="application/views/css/bootstrap.min.css" rel="stylesheet">

    <!-- CSS Personalizado -->
    <link href="application/views/css/css.css" rel="stylesheet">
	
	<!-- Jquery -->
	<script src="http://code.jquery.com/jquery-1.8.2.min.js" type="text/javascript" ></script>
	
		<!-- Jquery -->
	<script src="application/views/angular/angular.min.js" type="text/javascript" ></script>
	
	<script src="application/views/angular/angular-locale_pt-br.js" type="text/javascript" ></script>
	
<script>
angular.module("itlean",[]);
angular.module("itlean").controller("itLeanCtrl",function($scope){
$scope.infos = [<?php $y =0;
$num_tt = $this->db->count_all_results('cadastros');										
$query = $this->db->get('cadastros');
foreach ($query->result() as $row){										
echo '{id:"'.$row->id.'",';
echo 'nome:"'.$row->nome.'",';;
echo 'email:"'.$row->email.'"}';									
$y +=1;										
if($num_tt != $y){
echo ',';
}else{
echo '';
}
}?>];

$scope.isContatoSelecionado = function(infos){
return infos.some(function(info){
return info.selecionado;
});
};

$scope.ordenarPor = function(campo){
$scope.criterioDeOrdenacao = campo;
$scope.dirOrd = !$scope.dirOrd;
};

});
</script>
	
</head>

<body ng-controller="itLeanCtrl" class="ng-scope">

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
			

			<div id="message" class="alert alert-success">
            <button type="button" onclick="atualizar();" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <div id="mensagem">Cadastro realizado com sucesso!</div>
            </div>		
									
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Cadastro</h3>
                    </div>
                    <div class="panel-body">
					<?php $this->load->helper('form');
					echo form_open('','id="formulario_teste"');
					?>
                            <fieldset>
                                <div class="form-group">
								<label>Nome</label>
                                    <input class="form-control" placeholder="Nome" id="nome" name="nome" type="text" autocomplete="off">
                                </div>
                                <div class="form-group">
								<label>E-mail</label>
                                    <input class="form-control" placeholder="E-mail" id="email" name="email" type="email" autocomplete="off">
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
								
								<input class="btn btn-lg btn-success btn-block" type="button" value="Salvar" id="salvar" />
                            </fieldset>
					<?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	<div class="col-lg-3">
	</div>
	<div class="col-lg-6">
	<div class="form-group">
                                            <label>Busca no cadastro</label>
												<input type="text" class="form-control" ng-model="criterioDeBusca" placeholder="Procurar" />	
                                        </div>
	<div class="panel panel-default">
                        <div class="panel-heading">
                            Cadastro do Nome e do E-mail
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th><a href="" ng-click="ordenarPor('id')">Id</a></th>
                                            <th><a href="" ng-click="ordenarPor('nome')">Nome</a></th>
                                            <th><a href="" ng-click="ordenarPor('email')">E-mail</a></th>
                      
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
				
										<tr ng-class="{'selecionado negrito':contato.selecionado}" ng-repeat="info in infos | filter:criterioDeBusca | orderBy:criterioDeOrdenacao:dirOrd">
										<td>{{info.id}}</td>
										<td>{{info.nome}}</td>
										<td>{{info.email}}</td>
										</tr>
									                               
                                        
                                  
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
					</div>
	
	<script type="text/javascript">
$(document).ready(function() {
	$('#salvar').click(function() {
		var dados = $('#formulario_teste').serialize();
			$.ajax({
				url: '<?php echo base_url(); ?>' + 'index.php/registros_controller/cadatrar',
                type: 'POST',
                dataType: 'json',
                async: true,
                data: dados,
                                success: function(msg){
									$("#message").css('display','block');
                                    $("#mensagem").html('Cadastro realizado com sucesso!');
                                    if(msg == 1){
                                        jQuery.fn.reset = function(){
											$(this).each(function(){ this.reset();
											});
                                        }
                                        $("#formulario_teste").reset();										
                                    }
                                }
            });
            return false;

    });
});

function atualizar(){
window.location.href = "";
}
</script>

    <!-- jQuery -->
    <script src="application/views/js/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="application/views/js/bootstrap.min.js"></script>
</body>

</html>

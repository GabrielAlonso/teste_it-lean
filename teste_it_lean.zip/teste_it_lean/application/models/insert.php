<?php
class Insert_ctrl extends CI_Controller{

function __construct() {
parent::__construct();
$this->load->model('insert_model');
}
function cadastrar() {

$data = array(
'nome' => $this->input->post('nome',true),
'email' => $this->input->post('email',true)
);

//Transferindo para model
$this->insert_model->form_insert($data);
$data['message'] = 'Data Inserted Successfully';
//Loading View
$this->load->view('insert_view', $data);

}

}
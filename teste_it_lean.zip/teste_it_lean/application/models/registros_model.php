<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Registros_Model extends CI_Model {
     
    public function cadastrar(){
         
        // Inserção dos dados
        $this->db->insert('cadastros', array(
             
            'nome' => $this->input->post('nome', TRUE),
            'email' => $this->input->post('email', TRUE)
             
        )); 
    }
}
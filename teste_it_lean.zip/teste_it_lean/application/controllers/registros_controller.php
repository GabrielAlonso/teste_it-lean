<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Registros_Controller extends CI_Controller {
    public function index(){
        $this->load->view('cadastro');
    }
     
    public function cadatrar(){
        $this->load->model('registros_model');
        $this->registros_model->cadastrar();
        echo 1;
    }
}
<?php

class Teste extends CI_Controller{

function index(){
$this->load->view('teste');
}

}

